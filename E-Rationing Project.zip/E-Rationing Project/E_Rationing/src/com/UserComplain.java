package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserComplain
 */
@WebServlet("/UserComplain")
public class UserComplain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserComplain() {
        super();
        // TODO Auto-generated constructor stub
    }


    Connection con ;
   	PreparedStatement ps;
   	ResultSet rs;
   
   	String complain , email , name;
   	

   	public void init(ServletConfig config) throws ServletException {
   		try {
   			con = DbConnection.getConnection();
   			System.out.println("connection is " + con);
   		} catch (Exception e1) {
   			e1.printStackTrace();
   		}

   	}
   	public void doGet(HttpServletRequest request, HttpServletResponse response){
   		
   	}
   	
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   	{
   		try {
   			
   			String email=request.getParameter("h");
   			complain = request.getParameter("complain");
   			System.out.println("user name is"+email);
System.out.println("email is ="+email);
   			System.out.println("your complain is. . . .. " + complain);
   			String query = "UPDATE eration.userreg SET complain = '"+complain+"' WHERE email='"+email+"'";
   			
   			
   			
   			 ps = con.prepareStatement(query);
   			 int i=ps.executeUpdate();
   			
   			System.out.println("upade successfully");
   			if (i>0) 
   			{
   				System.out.println("Success update");
   				
   				System.out.println("update successfully");

   				
   				response.sendRedirect("userHome.jsp?status=success");
   			}

   			else {
   				System.out.println("update failed");

   				response.sendRedirect("allocateRation.jsp");
   			}
   			ps.close();
   		} catch (Exception e) {
   			e.printStackTrace();
   		}


   	
   		
   	}

   }

