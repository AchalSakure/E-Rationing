package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class TahsilLogin
 */
@WebServlet("/TahsilLogin")
public class TahsilLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection con ;
	PreparedStatement ps;
	ResultSet rs;

	String email;
	String password;

	public void init(ServletConfig config) throws ServletException {
		try {
			con = DbConnection.getConnection();
			System.out.println("connection is " + con);
		} catch (Exception e1) {
			e1.printStackTrace();
		}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {

			email = request.getParameter("username");
			password = request.getParameter("pass");

			System.out.println("username value. . . .. " + email);
			System.out.println("password value. . . .. " + password);
			ps = con.prepareStatement("SELECT * FROM eration.tahsilreg WHERE email=? and pass=?");
			
			ps.setString(1, email);
			ps.setString(2, password);
			rs = ps.executeQuery();
			HttpSession session = request.getSession();
			System.out.println("Login successfully");
			if (rs.next()) 
			{
				System.out.println("Success login");
				String email = rs.getString("email");
				System.out.println("Login successfully");

				session.setAttribute("email", email);
				response.sendRedirect("tahsilHome.jsp?status=success");
			}

			else {
				System.out.println("Login failed");

				response.sendRedirect("index.jsp");
			}
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}


	
		
	}

}
