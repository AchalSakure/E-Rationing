package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class VerifyOtp
 */
@WebServlet("/VerifyOtp")
public class VerifyOtp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Statement stmt;
    String username,verifedotp;
    
    
    public VerifyOtp() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void init(ServletConfig config) throws ServletException {
   		try {
   			con = DbConnection.getConnection();
   			System.out.println("connection is " + con);
   		} catch (Exception e1) {
   			e1.printStackTrace();
   		}

   	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
		username=request.getParameter("username");
		verifedotp=request.getParameter("userotp");
		System.out.println("user name is ="+username);
		System.out.println("user otp is ="+verifedotp);
		/* ResultSet rs=stmt.executeQuery("select * from eration.userreg where email='"+username+"' AND otpNo ='"+verifedotp+"'");
		//ps=con.prepareStatement("select * from eration.userreg WHERE email="+username+"AND otpNo="+verifedotp+";");
		System.out.println("valid till line");
		if(rs.next())
		{*/
		stmt=con.createStatement();
			String query = "UPDATE eration.userreg SET otpused = '"+verifedotp+"' WHERE otpNo ='"+verifedotp+"' AND email='"+username+"'";
	        System.out.println("execute update statement.."); 
			int n= stmt.executeUpdate(query);
			System.out.println(""+n);
	          if(n>0)
	          {
	        	  System.out.println("update success..");
	        	  response.sendRedirect("rationDistributedSuccess.jsp");
	          }
	          else
	          {
	        	  System.out.println("result set return "+n);
	        	  response.sendRedirect("verifyOtp.jsp");
	          }
	//	}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
		
		
	}


