package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class AllocateRation
 */
@WebServlet("/AllocateRation")
public class AllocateRation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllocateRation() {
        super();
        // TODO Auto-generated constructor stub
    }


    Connection con ;
   	PreparedStatement ps;
   	ResultSet rs;
   //statemnet stmt;
   	String allocate;
   	

   	public void init(ServletConfig config) throws ServletException {
   		try {
   			con = DbConnection.getConnection();
   			System.out.println("connection is " + con);
   		} catch (Exception e1) {
   			e1.printStackTrace();
   		}

   	}

   	
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   	{
   		try {

   			allocate = request.getParameter("allocate");
   			

   			System.out.println("ration aloocate is. . . .. " + allocate);
   			String query = "UPDATE eration.userreg SET allocate = '"+allocate+"'";
   			//ps = con.prepareStatement("SELECT * FROM eration.userreg WHERE email=? and pass=?");
   			
   			
   			 ps = con.prepareStatement(query);
   			 int i=ps.executeUpdate();
   			//HttpSession session = request.getSession();
   			System.out.println("upade successfully");
   			if (i>0) 
   			{
   				System.out.println("Success update");
   				//String email = rs.getString("email");
   				System.out.println("update successfully");

   				//session.setAttribute("email", email);
   				response.sendRedirect("distributedHome.jsp?status=success");
   			}

   			else {
   				System.out.println("update failed");

   				response.sendRedirect("allocateRation.jsp");
   			}
   			ps.close();
   		} catch (Exception e) {
   			e.printStackTrace();
   		}


   	
   		
   	}

   }

