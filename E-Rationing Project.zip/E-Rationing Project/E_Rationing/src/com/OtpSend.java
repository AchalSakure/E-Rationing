package com;
 import com.SendSMS;
 import java.text.DateFormat;
 import java.text.SimpleDateFormat;
 import java.sql.ResultSet;
 import java.sql.Statement;
 import com.DbConnection;
 import java.util.Date;
 import com.UrlRedirect;


 import com.MyStringRandomGen;
 import java.sql.Connection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class OtpSend
 */
@WebServlet("/OtpSend")
public class OtpSend extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OtpSend() {
        super();
        // TODO Auto-generated constructor stub
    }
    Connection con ;
	PreparedStatement ps;
	ResultSet rs;
	String email;
	

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession();  
        try {
        	Connection con= DbConnection.getConnection();
            Statement smt=con.createStatement();
        	String mno=request.getParameter("pid");
        	String allocate=request.getParameter("allocate");
        	//String mno=request.getParameter("mno");
        	System.out.print("mobile no is"+mno);
        	System.out.print("you have allocate ration"+allocate);
        	 rs=smt.executeQuery("select mno,email  from eration.userreg where mno='"+mno+"'");
        	 if(rs.next())
        	 {
        	  mno=rs.getString("mno"); 
        	  email=rs.getString("email"); 
		System.out.println("User reg  mobile no is ="+mno);
		System.out.println("User reg  name is ="+email);
		java.util.Date dategot = new java.util.Date();

	    Date currentDatetime = new Date(System.currentTimeMillis());
	        java.sql.Date sqlDate = new java.sql.Date(currentDatetime.getTime());
	        java.sql.Timestamp timestamp = new java.sql.Timestamp(currentDatetime.getTime());
	    
	        

	          MyStringRandomGen RT = new MyStringRandomGen();
	          String RandNo = RT.generateRandomString();
	          ResultSet rt=smt.executeQuery("select * from eration.userreg where mno='"+mno+"' AND email ='"+email+"'");
	          if(rt.next()){
	          
	          String OTP_date =  "";
	          System.out.println("Random no is ="+RandNo);
	          System.out.println("timestamp no is ="+timestamp);
	          System.out.println("email no is ="+ email);
	           String query = "UPDATE eration.userreg SET otpNo = '"+RandNo+"',otpdate = '"+timestamp+"' WHERE email ='"+email+"'";
	          int n= smt.executeUpdate(query);
	           String msgC="OTP for your CaRP is "+RandNo +" Do not share with anyone.";
	           String user ="vinodotp";
	           String password = "123123";
	           String sender = "CAPTCH";
	           String PhoneNumber = mno;
	           if(n>0){
	               
	               
	             String myURL = "http://www.smswave.in/panel/sendsms.php";
	               
	               SendSMS sSMS = new SendSMS();
	               sSMS.callURL(myURL, msgC, PhoneNumber);
	               System.out.println(" otp has been send");
	             
	           }else{
	           System.out.println("Not Updated");
	           }
        	 }
			
           
           
          rs=smt.executeQuery("select mno   from eration.userreg where mno='"+mno+"'");
          System.out.println("The result set is="+rs);
          if(rs.next()){
              HttpSession email=request.getSession(true);
                    email.setAttribute("email", mno);
                    System.out.println("Hello");
                    
              response.sendRedirect("verifyOtp.jsp?"+mno);
          }
          else{
              out.println("Mobile number not registred with this usename...");
          }
          
        } }
        catch(Exception e){
            out.println(e);
        }
        finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
