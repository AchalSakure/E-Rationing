package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserLogin
 */
@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

    Connection con ;
	PreparedStatement ps;
	ResultSet rs;

	String email;
	String pass;

	public void init(ServletConfig config) throws ServletException {
		try {
			con = DbConnection.getConnection();
			System.out.println("connection is " + con);
		} catch (Exception e1) {
			e1.printStackTrace();
		}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {

			email = request.getParameter("email");
			pass = request.getParameter("pass");

			System.out.println("username value. . . .. " + email);
			System.out.println("password value. . . .. " + pass);
			ps = con.prepareStatement("SELECT * FROM eration.userreg WHERE email=? and pass=?");
			
			ps.setString(1, email);
			ps.setString(2, pass);
			rs = ps.executeQuery();
			HttpSession session = request.getSession();
			System.out.println("Login successfully");
			if (rs.next()) 
			{
				System.out.println("Success login");
				String email = rs.getString("email");
				System.out.println("Login successfully");

				session.setAttribute("email", email);
				response.sendRedirect("userHome.jsp?status=success");
			}

			else {
				System.out.println("Login failed");

				response.sendRedirect("index.jsp");
			}
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}


	
		
	}

}
