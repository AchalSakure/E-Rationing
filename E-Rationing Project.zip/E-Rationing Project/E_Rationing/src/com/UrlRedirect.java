/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com;

/**
 *
 * @author Swapnil
 */
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UrlRedirect extends HttpServlet {

    public void sendSMS(HttpServletRequest request, HttpServletResponse response)throws ServletException, java.io.IOException {
    String contextPath= "http://www.java2s.com";
    response.sendRedirect(response.encodeRedirectURL(contextPath + "/maps"));
    
    }
  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, java.io.IOException {
        String contextPath= "http://www.java2s.com";
    response.sendRedirect(response.encodeRedirectURL(contextPath + "/maps"));
  }
}
