package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DbConnection;

/**
 * Servlet implementation class UserReg
 */
@WebServlet("/UserReg")
public class UserReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserReg() {
        super();
        // TODO Auto-generated constructor stub
    }

    Connection con = null;
	PreparedStatement ps;
	ResultSet rs;
	String name, fname, lname, adharno, rationno, state, district, tahsil, email, pass , distributedname , mno;
	Integer otpused=1;

	public void init(ServletConfig config) throws ServletException {
		try {

			con = DbConnection.getConnection();
			System.out.println("connection is " + con);

		} catch (Exception e1) {
			e1.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		name = request.getParameter("name");
		fname = request.getParameter("fname");
		lname = request.getParameter("lname");
		adharno = request.getParameter("adharno");
		rationno = request.getParameter("rationno");
		state = request.getParameter("branch");
		district = request.getParameter("year");
		tahsil = request.getParameter("subject");
		distributedname = request.getParameter("distributedname");
		email = request.getParameter("email");
		pass = request.getParameter("pass");
		mno = request.getParameter("mno");
		System.out.println("status is ="+otpused);
System.out.println("name ="+name);
System.out.println("fname="+fname);
System.out.println("lname="+lname);
System.out.println("adhar no="+adharno);
System.out.println("ration no-="+rationno);
System.out.println("state ="+state);
System.out.println("disrtrict ="+district);
System.out.println("tahsil ="+tahsil);
System.out.println("distributed name ="+distributedname);
System.out.println("email ="+email);
System.out.println("pass ="+pass);
System.out.println("mno="+mno);
		try {
			Statement st = con.createStatement();
			//INSERT INTO `eration`.`userreg` (`name`, `fname`, `lname`, `adharno`, `rationno`, `state`, `district`, `tahsil`, `distributedname`, `email`, `pass`, `mno`, `otpNo`, `otpused`, `otpdate`, `allocate`, `complain`) VALUES ('ganesh', 'asdf', 'asdfg', '12345', '123456', 'mh', 'mh', 'mh', 'suhas', 'ganesh', 'ganesh', '1234', '12334', '1', '2017-01-11', '123', 'zxcvb');
			
			
			int r = st
					.executeUpdate("INSERT INTO `eration`.`userreg` (`name`, `fname`, `lname`, `adharno`, `rationno`, `state`, `district`, `tahsil`, `distributedname`, `email`, `pass`, `mno`,`otpused`) VALUES ('"
					+ name
					+ "', '"
					+ fname
					+ "', '"
					+ lname
					+ "','"
					+ adharno
					+ "', '"
					+ rationno
					+ "', '"
					+ state
					+ "', '"
					+ district + "','" + tahsil + "','" + distributedname + "', '" + email + "', '" + pass + "','" + mno + "','" + otpused + "');");
			if (r > 0) {
				System.out.println("Data Insert Done");
				response.sendRedirect("index.jsp");

			}

		} catch (Exception e) {
			System.out.println("Exception is " + e);
		}

	}

}
