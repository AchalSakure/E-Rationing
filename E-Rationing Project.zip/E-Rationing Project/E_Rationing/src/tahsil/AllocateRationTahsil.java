package tahsil;
import com.DbConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AllocateRationTahsil")
public class AllocateRationTahsil extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public AllocateRationTahsil() {
        super();
        // TODO Auto-generated constructor stub
    }

    Connection con ;
   	PreparedStatement ps;
   	ResultSet rs;
   //statemnet stmt;
   	String allocate, distributername;
   	

   	public void init(ServletConfig config) throws ServletException {
   		try {
   			con = DbConnection.getConnection();
   			System.out.println("connection is " + con);
   		} catch (Exception e1) {
   			e1.printStackTrace();
   		}

   	}

   	
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   	{
   		try {

   			allocate = request.getParameter("allocate");
   			distributername=request.getParameter("distributername");
   			

   			System.out.println("ration aloocate is. . . .. " + allocate);
   			System.out.println("ration aloocate is. . . .. " + distributername);
   			String query = "UPDATE eration.distributedreg SET allocateration = '"+allocate+"' WHERE distributedname='"+distributername+"'";
   			//ps = con.prepareStatement("SELECT * FROM eration.userreg WHERE email=? and pass=?");
   			
   			
   			 ps = con.prepareStatement(query);
   			 int i=ps.executeUpdate();
   			//HttpSession session = request.getSession();
   			System.out.println("upade successfully");
   			if (i>0) 
   			{
   				System.out.println("Success update");
   				//String email = rs.getString("email");
   				System.out.println("update successfully");

   				//session.setAttribute("email", email);
   				response.sendRedirect("tahsilHome.jsp?status=success");
   			}

   			else {
   				System.out.println("update failed");

   				response.sendRedirect("allocatedRationTahsil.jsp");
   			}
   			ps.close();
   		} catch (Exception e) {
   			e.printStackTrace();
   		}


   	
   		
   	}

   }

